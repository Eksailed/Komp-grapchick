using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab1a
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool drawRect;

        private void button1_Click(object sender, EventArgs e)
        {
            // Выбираем перо myPen красного цвета толщиной в 1 пиксел:
            Pen myPen = new Pen(Color.Red, 1);
            // Объявляем объект «g» класса Graphics и предоставляем
            // ему возможность рисования на pictureBox1:
            Graphics g = pictureBox1.CreateGraphics();
            // Рисуем прямоугольник:
            g.DrawRectangle(myPen, 0, 0, pictureBox1.Size.Width - 1,
                pictureBox1.Size.Height - 1);
            g.Dispose();
            // GTK на Mac рисует на Paint, поэтому ещё Invalidate:
            drawRect = true;
            pictureBox1.Invalidate();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            if (!drawRect) return;
            e.Graphics.DrawRectangle(Pens.Red, 0, 0,
                pictureBox1.Size.Width - 1, pictureBox1.Size.Height - 1);
        }
    }
}
