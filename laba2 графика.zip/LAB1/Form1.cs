﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace LAB1
{
    public partial class Form1 : Form
    {
        private PictureBox pictureBox;
        private Button btnPixel, btnMillimeter, btnInch, btnClear;
        private Bitmap bitmap;

        private readonly float xMin = -4f;
        private readonly float xMax = 4f;
        private float yMin, yMax;

        private readonly Color graphColor = Color.FromArgb(210, 224, 200);
        private readonly Color clearColor = Color.FromArgb(100, 150, 200);
        private readonly Color axisColor = Color.Blue;
        private readonly Color frameColor = Color.Blue;

        public Form1()
        {
            this.Text = "График y = 2x³ + 2x";
            this.Size = new Size(1000, 600);

            pictureBox = new PictureBox();
            pictureBox.Location = new Point(50, 50);
            pictureBox.Size = new Size(900, 450);
            pictureBox.BackColor = Color.FromKnownColor(KnownColor.ControlLightLight);
            this.Controls.Add(pictureBox);

            btnPixel = new Button { Text = "Pixel", Location = new Point(50, 520), Size = new Size(80, 30) };
            btnPixel.Click += BtnPixel_Click;
            this.Controls.Add(btnPixel);

            btnMillimeter = new Button { Text = "Millimeter", Location = new Point(150, 520), Size = new Size(80, 30) };
            btnMillimeter.Click += BtnMillimeter_Click;
            this.Controls.Add(btnMillimeter);

            btnInch = new Button { Text = "Inch", Location = new Point(250, 520), Size = new Size(80, 30) };
            btnInch.Click += BtnInch_Click;
            this.Controls.Add(btnInch);

            btnClear = new Button { Text = "Очистить", Location = new Point(350, 520), Size = new Size(80, 30) };
            btnClear.Click += BtnClear_Click;
            this.Controls.Add(btnClear);

            ComputeYRange();

            bitmap = new Bitmap(pictureBox.Width, pictureBox.Height);
            using (Graphics g = Graphics.FromImage(bitmap))
                g.Clear(pictureBox.BackColor);
            pictureBox.Image = bitmap;
        }

        private float Func(float x) => 2 * x * x * x + 2 * x;

        private void ComputeYRange()
        {
            int steps = 1000;
            float minY = float.MaxValue, maxY = float.MinValue;
            for (int i = 0; i <= steps; i++)
            {
                float x = xMin + (xMax - xMin) * i / steps;
                float y = Func(x);
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
            float margin = (maxY - minY) * 0.1f;
            yMin = minY - margin;
            yMax = maxY + margin;
            if (yMin > 0) yMin = -0.1f;
            if (yMax < 0) yMax = 0.1f;
        }

        private void DrawGraph(GraphicsUnit unit)
        {
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.Clear(pictureBox.BackColor);
                g.PageUnit = unit;

                float dpiX = g.DpiX;
                float dpiY = g.DpiY;
                float unitsPerInch = (unit == GraphicsUnit.Pixel) ? 1f :
                                     (unit == GraphicsUnit.Millimeter) ? 25.4f : 1f;

                float widthUnits = pictureBox.Width * (unitsPerInch / dpiX);
                float heightUnits = pictureBox.Height * (unitsPerInch / dpiY);
                float centerX = widthUnits / 2;
                float centerY = heightUnits / 2;
                float xRange = xMax - xMin;
                float yRange = yMax - yMin;

                using (Pen pen = new Pen(frameColor))
                    g.DrawRectangle(pen, 0, 0, widthUnits, heightUnits);

                using (Pen pen = new Pen(axisColor))
                {
                    float y0Unit = centerY - (0 - (yMin + yMax) / 2) * (heightUnits / yRange);
                    float xLeftUnit = centerX + (xMin - (xMin + xMax) / 2) * (widthUnits / xRange);
                    float xRightUnit = centerX + (xMax - (xMin + xMax) / 2) * (widthUnits / xRange);
                    g.DrawLine(pen, xLeftUnit, y0Unit, xRightUnit, y0Unit);

                    float x0Unit = centerX + (0 - (xMin + xMax) / 2) * (widthUnits / xRange);
                    float yBottomUnit = centerY - (yMin - (yMin + yMax) / 2) * (heightUnits / yRange);
                    float yTopUnit = centerY - (yMax - (yMin + yMax) / 2) * (heightUnits / yRange);
                    g.DrawLine(pen, x0Unit, yBottomUnit, x0Unit, yTopUnit);
                }

                using (Pen pen = new Pen(graphColor))
                {
                    int steps = 1000;
                    PointF[] points = new PointF[steps + 1];
                    for (int i = 0; i <= steps; i++)
                    {
                        float xLogic = xMin + (xMax - xMin) * i / steps;
                        float yLogic = Func(xLogic);
                        points[i] = new PointF(
                            centerX + (xLogic - (xMin + xMax) / 2) * (widthUnits / xRange),
                            centerY - (yLogic - (yMin + yMax) / 2) * (heightUnits / yRange)
                        );
                    }
                    g.DrawLines(pen, points);
                }

                pictureBox.Image = bitmap;
            }
        }

        private void BtnPixel_Click(object sender, EventArgs e) => DrawGraph(GraphicsUnit.Pixel);
        private void BtnMillimeter_Click(object sender, EventArgs e) => DrawGraph(GraphicsUnit.Millimeter);
        private void BtnInch_Click(object sender, EventArgs e) => DrawGraph(GraphicsUnit.Inch);

        private void BtnClear_Click(object sender, EventArgs e)
        {
            bitmap = new Bitmap(pictureBox.Width, pictureBox.Height);
            using (Graphics g = Graphics.FromImage(bitmap))
                g.Clear(clearColor);
            pictureBox.Image = bitmap;
        }
    }
}
